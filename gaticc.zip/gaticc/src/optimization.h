#pragma once

#include "onnx_parser.h"

void split_large_kernel(Op::Graph &g);