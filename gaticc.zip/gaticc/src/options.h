#pragma once

int dispatch();
void dispatch_compile_ops();
void dispatch_info_ops();
void dispatch_sim_ops();
void dispatch_run_ops();
